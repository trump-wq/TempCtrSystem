package com.google.demo;

import com.google.demo.entity.Data;
import com.google.demo.mapper.DataMapper;
import com.google.demo.service.IDataService;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Timestamp;


@SpringBootTest
class DemoApplicationTests {

    @Autowired
    DataMapper dataMapper;
    @Autowired
    IDataService dataService;

    @SneakyThrows
    @Test
    void contextLoads() {

        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        ArrayList<Data> list = new ArrayList<>();
        Data data = new Data();
        Data data1 = new Data();
        Data data2 = new Data();

        data.setDatano(0);
        data.setDno(1L);
        data.setData(1111);
        data.setDay(new Timestamp(System.currentTimeMillis()));

        Thread.sleep(1000);
        data1.setDatano(0);
        data1.setDno(1L);
        data1.setData(1111);
        data1.setDay(new Timestamp(System.currentTimeMillis()));
        Thread.sleep(1000);
        data2.setDatano(0);
        data2.setDno(1L);
        data2.setData(1111);
        data2.setDay(new Timestamp(System.currentTimeMillis()));
        list.add(data);
        list.add(data1);
        list.add(data2);
        list.add(data);
        list.add(data1);
        list.add(data2);
        list.add(data);
        list.add(data1);
        list.add(data2);
        list.add(data);
        list.add(data1);
        list.add(data2);
        list.add(data);
        list.add(data1);
        list.add(data2);
        list.add(data);
        list.add(data1);
        list.add(data2);
        int res = dataService.insertBatch(list);
        System.out.println(res);
    }

}
