package com.google.demo;

import gnu.io.SerialPort;

import java.io.IOException;
import java.io.InputStream;


public class Receive implements Runnable{

    SerialPort serialPort;
    public Receive(SerialPort serialPort){
        this.serialPort = serialPort;
    }


    @Override
    public void run(){
        byte[] dat;
        while (true) {
            //从单片机接收到的数据
            dat = uartReceiveDatafromSingleChipMachine(serialPort);
            if (dat != null && dat.length > 0) {
                String dataReceive = null;
                dataReceive = new String(dat);

                System.out.println("从串口接收的数据：" + dataReceive);
            } else {
                //System.out.println("接收到的数据为空！");
            }
        }

    }
    public static   byte[] uartReceiveDatafromSingleChipMachine(SerialPort serialPort) {
        byte[] receiveDataPackage=null;
        InputStream in=null;
        try {
            in=serialPort.getInputStream();
            // 获取data buffer数据长度
            int bufferLength=in.available();
            while(bufferLength!=0) {
                receiveDataPackage=new byte[bufferLength];
                in.read(receiveDataPackage);
                bufferLength=in.available();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return receiveDataPackage;
    }

}
