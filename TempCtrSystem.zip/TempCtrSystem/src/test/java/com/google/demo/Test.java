package com.google.demo;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

public class Test {
    public static void main(String[] args) throws IOException {
        InputStream in = new BufferedInputStream(System.in);
        byte[] bytes = new byte[100];
        int len = in.read(bytes);
        for (int i = 0 ;i < len ;++i){
            System.out.print(bytes[i]);
        }
    }
}
