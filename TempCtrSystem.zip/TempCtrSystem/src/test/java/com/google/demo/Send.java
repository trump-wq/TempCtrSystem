package com.google.demo;

import gnu.io.SerialPort;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;


public class Send implements Runnable{
    SerialPort serialPort;

    public Send(SerialPort serialPort) {
        this.serialPort = serialPort;
    }

    @Override
    public void run() {
        byte []datByte;
        Scanner sc = new Scanner(System.in);


        while (true){

            String dataSend = sc.nextLine();
            if (!dataSend.equals("")){
                datByte = dataSend.getBytes();
                uartSendDatatoSerialPort(serialPort, datByte);
                //System.out.println("-------------------------------------------------------");
                System.out.println( "发送到串口的数据：" + dataSend);
            }
        }
    }
    public static void uartSendDatatoSerialPort(SerialPort serialPort, byte[] dataPackage) {
        OutputStream out=null;
        try {
            out=serialPort.getOutputStream();
            out.write(dataPackage);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //关闭输出流
            if(out!=null) {
                try {
                    out.close();
                    out=null;
                    //System.out.println("数据已发送完毕!");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
