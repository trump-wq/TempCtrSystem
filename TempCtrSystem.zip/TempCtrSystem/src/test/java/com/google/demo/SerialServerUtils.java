package com.google.demo;

import gnu.io.SerialPort;

import static com.google.demo.SerialTools.portParameterOpen;

public class SerialServerUtils {
    public static void main(String[] args) {
        // 打开串口
        SerialPort serialPort = portParameterOpen("COM2", 9600);

        Receive receive = new Receive(serialPort);
        Send send = new Send(serialPort);
        Thread thread1 = new Thread(receive);
        Thread thread2 = new Thread(send);
        thread1.run();
        thread2.run();
    }
}
