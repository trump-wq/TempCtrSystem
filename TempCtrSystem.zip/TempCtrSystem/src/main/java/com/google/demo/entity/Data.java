package com.google.demo.entity;

import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class Data implements Serializable {
  private long datano;
  private long dno;
  private long data;
  private java.sql.Timestamp day;
}
