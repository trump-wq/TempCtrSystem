package com.google.demo.service.impl;

import com.google.demo.entity.Device;
import com.google.demo.mapper.DeviceMapper;
import com.google.demo.service.IDeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DeviceServiceImpl implements IDeviceService {
    @Autowired
    DeviceMapper deviceMapper;
    @Override
    public List<Device> loadAllDevice() {
        return deviceMapper.loadAllDevice();
    }
}
