package com.google.demo.service.impl;

import com.google.demo.entity.Users;
import com.google.demo.mapper.UserMapper;
import com.google.demo.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements IUserService {
    @Autowired
    UserMapper userMapper;

    @Override
    public long login(Users users) {
        return userMapper.login(users);
    }
}
