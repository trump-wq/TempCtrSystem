package com.google.demo.service.impl;

import com.github.pagehelper.PageHelper;
import com.google.demo.entity.Data;
import com.google.demo.mapper.DataMapper;
import com.google.demo.pool.DataPool;
import com.google.demo.service.IDataService;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

@Service
public class DataServiceImpl implements IDataService {
    @Autowired
    private DataMapper dataMapper;
    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;
    @Autowired
    private DataPool dataPool;

    @Override
    public List<Map<String, Object>> loadBySeconds(int dno,int page,int pageSize) {
        PageHelper.startPage(page,pageSize);
        return dataMapper.loadBySeconds(dno);
    }

    @Override
    public int calcSecondsMaxPage(int dno,int pageSize) {
        int max = dataMapper.calcSecondsMaxPage(dno);
        return (max + pageSize - 1) / pageSize;
    }

    @Override
    public List<Map<String, Object>> loadByHour(int dno,int page,int pageSize){
        PageHelper.startPage(page,pageSize);
        return dataMapper.loadByHour(dno);
    }

    @Override
    public int calcHourMaxPage(int dno,int pageSize) {
        int max = dataMapper.calcHourMaxPage(dno);
        return (max + pageSize - 1) / pageSize;
    }


    //TODO 定时10秒批量插入
    @Scheduled(fixedDelay = 10000)
    public void insertDataSchedule(){
        List point = dataPool.getList();
        //TODO 如果data pool为空就不用插入
        if (point.size() != 0) {
            insertBatch(point);
            System.out.println("batch insert success");
        }
    }

    @Override
    //TODO 开启编程式事务，所以如果报错，数据有可能会回滚丢失
    public int insertBatch(List<Data> dataList) {
// TODO Auto-generated method stub
        //int result = 0;
        SqlSession batchSqlSession = null;
        try {
            batchSqlSession = this.sqlSessionTemplate
                    .getSqlSessionFactory()
                    .openSession(ExecutorType.BATCH, false);// 获取批量方式的sqlsession
            //通过新的session获取mapper
            DataMapper  mapper = batchSqlSession.getMapper(DataMapper.class);

            //int batchCount = 1000;// 每批commit的个数
            int batchCount = 10;// 每批commit的个数
            int batchLastIndex = batchCount;// 每批最后一个的下标

            for (int index = 0; index < dataList.size();) {

                if (batchLastIndex >= dataList.size()) {
                    batchLastIndex = dataList.size();
                }
                mapper.insertBatch(dataList.subList(index, batchLastIndex));
                batchSqlSession.commit();

                if (batchLastIndex >= dataList.size())
                    break;

                if (batchLastIndex < dataList.size()){
                    index = batchLastIndex;// 设置下一批下标
                    batchLastIndex = index +(batchCount-1);
                }

            }
            batchSqlSession.commit();
        } catch(Exception e) {
            e.printStackTrace();
        }
        finally {
            batchSqlSession.close();
        }
        //System.out.println(result);
        return dataList.size();
    }
}
