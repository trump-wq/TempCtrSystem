package com.google.demo.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import java.io.Serializable;

@Component
@Scope("singleton")
/**
 * 单片机属性
 * 静态资源
 */
public class AT89C51 implements Serializable {
    private static int current;
    private static int lower = 0;
    private static int upper = 0;

    //信号量，前端为生产者
    volatile static int signal = 0;

    public synchronized int getLower() {
        return lower;
    }
    public synchronized int getUpper() {
        return upper;
    }

    /**
     * 给前端用的
     * @return
     */
    public int getCurrent() {
        return current;
    }

    /**
     * 给下位机用的
     * @param current
     */
    public void setCurrent(int current) {
        this.current = current;
    }

    /**
     * 给前端生产者用的
     * @param lower
     * @param upper
     */
    public synchronized void setLowerAndUpper(int lower, int upper) {
        this.lower = lower;
        this.upper = upper;
        this.V();
    }

    //TODO P操作
    public synchronized void P(){
        signal--;
        while (signal < 0){
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    //TODO V操作
    public synchronized void V(){
        signal++;
        notify();
    }

    //TODO 给下位机更新上下限用的
    public synchronized void setLower(int lower) {
        AT89C51.lower = lower;
    }
    //TODO 给下位机更新上下限用的
    public synchronized void setUpper(int upper) {
        AT89C51.upper = upper;
    }
}
