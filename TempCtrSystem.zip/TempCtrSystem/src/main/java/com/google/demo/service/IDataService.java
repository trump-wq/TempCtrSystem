package com.google.demo.service;

import com.google.demo.entity.Data;

import java.util.List;
import java.util.Map;

public interface IDataService {
    //通过设备号按分钟查询数据，返回每分钟平均值
    List<Map<String,Object>> loadBySeconds(int dno,int page,int pageSize);
    int calcSecondsMaxPage(int dno,int pageSiz);

    //通过设备号按小时查询数据，返回每小时平均值
    List<Map<String,Object>> loadByHour(int dno,int page,int pageSize);
    int calcHourMaxPage(int dno,int pageSiz);

    //批处理插入
    int insertBatch(List<Data> dataList);
}
