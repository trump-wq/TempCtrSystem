package com.google.demo.controller;

import com.google.demo.entity.Users;
import com.google.demo.service.IUserService;
import com.google.demo.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/users")
@CrossOrigin(origins = "*", maxAge = 3600)
public class UserController {
    @Autowired
    private IUserService userServiceImpl;

    @GetMapping(value = "/login",params = {"uname","pwd"})
    @ResponseBody
    public long userLogin(@RequestParam String uname,@RequestParam String pwd){
        Users users = new Users();
        users.setUname(uname);
        users.setPwd(pwd);
        return userServiceImpl.login(users);
    }

}
