package com.google.demo.utils;

import com.google.demo.entity.AT89C51;
import java.io.IOException;

public class SendTo51Util implements Runnable {
    private static AT89C51 c51;
    public SendTo51Util(AT89C51 c51) {
        this.c51 = c51;
    }

    @Override
    public void run() {
        ContinueReadUtil cRead = new ContinueReadUtil();
        int i = cRead.startComPort();
        if (i == 1) {
            // 启动线程来处理收到的数据
            cRead.start();
            try {
                while (true){
                    c51.P();
                    String s = "["+c51.getLower()+","+c51.getUpper()+"]";
                    ContinueReadUtil.outputStream.write(s.getBytes("gbk"),0,s.getBytes("gbk").length);
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else {
            return;
        }
    }
}
