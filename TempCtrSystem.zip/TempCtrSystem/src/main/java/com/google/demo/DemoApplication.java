package com.google.demo;


import com.google.demo.entity.AT89C51;
import com.google.demo.utils.SendTo51Util;
import com.google.demo.utils.SpringUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@EnableAsync
@EnableScheduling
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
        AT89C51 c51 = SpringUtil.getBean(AT89C51.class);
        SendTo51Util to51Util = new SendTo51Util(c51);
        Thread thread = new Thread(to51Util);
        //TODO 监听串口线程
        thread.start();

        //new Thread(new SendTo51Util(SpringUtil.getBean(AT89C51.class))).start();

    }

}
