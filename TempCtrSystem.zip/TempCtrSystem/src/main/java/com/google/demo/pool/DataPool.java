package com.google.demo.pool;

import com.google.demo.entity.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@Scope("singleton")
/**
 * 数据常量池
 */
public class DataPool {
    private static volatile List<Data> list = new ArrayList<>(1000);

    //读写缓存池时候加锁
    private static Object lockWrite = new Object();
    private static Object lockRead = new Object();


    public void addData(Data data) {
        synchronized (lockWrite) {
            list.add(data);
        }
    }
    public List<Data> getList() {
        synchronized (lockWrite) {
            List point = new ArrayList(list);
            list.clear();
            return point;
        }
    }
}
