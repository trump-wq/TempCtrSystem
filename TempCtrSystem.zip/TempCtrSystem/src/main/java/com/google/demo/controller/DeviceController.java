package com.google.demo.controller;

import com.google.demo.entity.Device;
import com.google.demo.service.IDeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/device")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DeviceController {
    @Autowired
    private IDeviceService deviceServiceImpl;

    @GetMapping(value = "/loadAllDevice")
    @ResponseBody
    public List<Device> loadAllDevice(){
        return deviceServiceImpl.loadAllDevice();
    }
}
