package com.google.demo.mapper;

import com.google.demo.entity.Data;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Mapper
@Repository
public interface DataMapper {
    //通过设备号按分钟查询数据，返回每分钟平均值
    List<Map<String,Object>> loadBySeconds(int dno);
    int calcSecondsMaxPage(int dno);

    //通过设备号按小时查询数据，返回每小时平均值
    List<Map<String,Object>> loadByHour(int dno);
    int calcHourMaxPage(int dno);

    //批处理插入
    int insertBatch(List<Data> dataList);
}
