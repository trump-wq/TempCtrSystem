package com.google.demo.mapper;

import com.google.demo.entity.Users;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserMapper {
    //用户登录
    long login(Users users);
}
