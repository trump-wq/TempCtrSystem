package com.google.demo.utils;

import com.google.demo.entity.AT89C51;
import com.google.demo.entity.Data;
import com.google.demo.pool.DataPool;
import org.apache.activemq.command.ActiveMQTopic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.sql.Timestamp;
@Component
@Scope("singleton")
public class DataUtil {
    @Autowired
    DataPool dataPool;
    @Autowired
    AT89C51 c51;
    @Resource
    JmsMessagingTemplate jmsMessagingTemplate;


    //TODO 异步解析消息字符串
    @Async
    public void deJson(String json){
        if (json.length() < 12) {
            throw new ArrayIndexOutOfBoundsException("丢包");
        }
        String[] s = json.split(",", 3);
        if (!s[0].contains("[") && !s[2].contains("]")){
            throw new ArrayIndexOutOfBoundsException("丢包");
        }

        s[0] = (s[0].split("\\["))[1];
        s[2] = (s[2].split("\\]"))[0];

        if (s[0].contains(".")) {
            s[0] = s[0].split("\\.")[0];
        }

        int current = Integer.parseInt(s[0]);
        int lower = Integer.parseInt(s[1]);
        int upper = Integer.parseInt(s[2]);

        //current不涉及异步
        c51.setCurrent(current);
        jLowerAndUpper(lower, upper);

        System.out.println("decode success");
        Data data = new Data();
        data.setDatano(0);
        data.setDno(1);
        data.setData(current);
        data.setDay(new Timestamp(System.currentTimeMillis()));
        dataPool.addData(data);

        System.out.println("put into pool success");

    }


    /**
     * 判断上下限阈值是否改变，如果改变则发送到ActiveMQ等待队列
     * @param lower
     * @param upper
     */
    public void jLowerAndUpper(int lower, int upper) {
        if (c51.getLower() != lower || c51.getUpper() != upper){
            c51.setLower(lower);
            c51.setUpper(upper);
            ActiveMQTopic topic = new ActiveMQTopic("test1");
            jmsMessagingTemplate.convertAndSend(topic,"{'lower':"+lower+",'upper':"+upper+"}");
            System.out.println("sent to mqtt success");
        }
    }

}
