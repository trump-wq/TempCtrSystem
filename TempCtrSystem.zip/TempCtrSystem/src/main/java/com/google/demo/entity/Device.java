package com.google.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class Device implements Serializable {
  private long dno;
  private String dname;
  private String unit;

}
