package com.google.demo.controller;

import com.google.demo.entity.AT89C51;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/microchip")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AT89C51Controller {

    private static AT89C51 c51;
    public AT89C51Controller(AT89C51 c51) {
        this.c51 = c51;
    }

    @GetMapping("/getLower")
    @ResponseBody
    public int getLower(){
        return c51.getLower();
    }

    @GetMapping("/setLowerAndUpper")
    @ResponseBody
    public int setLower(@RequestParam("lower") int lower,@RequestParam("upper") int upper){
        c51.setLowerAndUpper(lower,upper);
        return 1;
    }
    @GetMapping("/getUpper")
    @ResponseBody
    public int getUpper(){
        return c51.getUpper();
    }

    @GetMapping("/getCurrent")
    @ResponseBody
    public int getCurrent(){
        return c51.getCurrent();
    }

}
