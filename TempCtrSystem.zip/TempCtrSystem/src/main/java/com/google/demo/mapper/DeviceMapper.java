package com.google.demo.mapper;

import com.google.demo.entity.Device;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface DeviceMapper {
    //查询所有设备
    List<Device> loadAllDevice();
}
