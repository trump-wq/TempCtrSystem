package com.google.demo.service;

import com.google.demo.entity.Device;

import java.util.List;

public interface IDeviceService {
    //查询所有设备
    List<Device> loadAllDevice();
}
