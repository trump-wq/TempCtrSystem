package com.google.demo.controller;

import com.google.demo.service.IDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/data")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DataController {
    @Autowired
    private IDataService dataServiceImpl;

    @RequestMapping(value = "/loadDataBySeconds/{dno}/{page}/{pageSize}")
    @ResponseBody
    public List loadDataBySeconds(@PathVariable(value = "dno") int dno,
                                  @PathVariable(value = "page") int page,
                                  @PathVariable(value = "pageSize") int pageSize){
        int max = dataServiceImpl.calcSecondsMaxPage(dno,pageSize);
        if (page > max){
            page = 1;
        }
        List<Map<String, Object>> list = dataServiceImpl.loadBySeconds(dno,page,pageSize);
        //System.out.println(list.toString());
        return list;
    }

    @GetMapping(value = "/loadDataByHour/{dno}/{page}/{pageSize}")
    @ResponseBody
    public List loadDataByHour(@PathVariable(value = "dno") int dno,
                                  @PathVariable(value = "page") int page,
                                  @PathVariable(value = "pageSize") int pageSize){
        int max = dataServiceImpl.calcHourMaxPage(dno,pageSize);
        if (page > max){
            page = 1;
        }
        List<Map<String, Object>> list = dataServiceImpl.loadByHour(dno,page,pageSize);
        return list;
    }
}
