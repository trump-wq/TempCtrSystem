package com.google.demo.service;

import com.google.demo.entity.Users;

public interface IUserService {
    //用户登录
    long login(Users users);
}
