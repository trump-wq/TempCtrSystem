package com.google.demo.entity;



import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class Users implements Serializable {
  private long uno;
  private String uname;
  private String pwd;
  private long role;

}
