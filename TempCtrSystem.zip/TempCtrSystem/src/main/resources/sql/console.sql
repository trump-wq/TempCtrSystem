create database tempctl;
create table device(
  dno int auto_increment,
  dname varchar(20),
  unit varchar(20),
  primary key (dno)
);
create table data(
  datano int auto_increment,
  dno int,
  data int,
  day datetime,
  primary key (datano),
  foreign key (dno) references device(dno)
);
create table users(
  uno int auto_increment,
  uname varchar(20) unique ,
  pwd varchar(100),
  role int check ( role in(0,1) ),
  primary key (uno)
);
insert into device values (default,'8051','temperature');
insert into data values (default,2,3,now());
insert into users values (default,'admin',md5('123456'),0);
select *from data;
##############################################################
select uno from users where uname = 'admin' and pwd = md5('123456');

select *from device;

select device.dno '设备id',dname '设备名',datano '数据采集id',data '采集数据',unit '单位',day '时间' from device
  left join data d on device.dno = d.dno order by day desc;



select device.dno '设备id',dname '设备名',datano '数据采集id',avg(data) '每小时数据平均值',unit '单位',date_format(day,'%Y-%m-%d %H') '时间'
  from device left join data d on device.dno = d.dno group by hour(day);

################################################################

select avg(data) ,date_format(day,'%Y-%m-%d %H') from data group by hour(day);

select device.dno '设备id',dname '设备名',datano '数据采集id',data '采集数据',unit '单位',day '时间' from device
    left join data d on device.dno = d.dno  where device.dno = 2 order by day desc ;
select count(*) from data where dno = 1 group by hour(day) ;
select count(*)from (select count(*) from data group by hour(day)) t;
select uno from users where uname = 'admin' and pwd = md5('123456');

select device.dno,dname,datano,data ,unit,day from device
left join data d on device.dno = d.dno  where device.dno = 1 order by day desc;
show create table data;